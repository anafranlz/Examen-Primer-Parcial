//177438 Ana Maria Franco Lopez
import java.util.Scanner;

public class Examen {
	Scanner scan = new Scanner(System.in);
	int i;
//String para el primer problema
	public String myString = "anita lava la tina";
	int length;
	String cadenita, mayus, myStringSinMayus, stringPrimeraMayus;
//String para el segundo problema
	public String myStringTwo = "el principe de egipto";
	String cadenaInvertida;
	int longitudStringTwo;
//String para el tercer problema
	public String myStringThree = "hasta luego cocodrilo";
	String cadenaConMayus;
	char vocal;
//String para el ultimo problema
	String palabra;
	int izquierda, derecha, resultado;
	
	//Primera mayuscula
	//Dada una cadena, convierta la primera letra en mayuscula
	public void primeraMayuscula()
	{
		length = myString.length();
		cadenita = myString.substring(0, 1);
		mayus = cadenita.toUpperCase();
		myStringSinMayus = myString.substring(1, length);
		stringPrimeraMayus = mayus.concat(myStringSinMayus);
		System.out.println(stringPrimeraMayus);
		return;
	}
	
	//Invertir una cadena
	//Invierta una cadena. Dada una cadena inicial escriba un programa para invertirla.
	public void invertirCadena() 
	{
        cadenaInvertida = "";
        longitudStringTwo = myStringTwo.length();
        for (int i = (longitudStringTwo - 1); i >= 0; i--)
        {
            cadenaInvertida = cadenaInvertida + myStringTwo.charAt(i);
        }
        System.out.println(cadenaInvertida);
        return;
    }
	
	//Vocales en mayuscula
	//tome una cadena y convierta todas las vocales a mayusculas.
	public void vocalesMayuscula()
	{
		cadenaConMayus = "";
	    for (i = 0; i < myStringThree.length(); i++) 
	    {
	      vocal = myStringThree.charAt(i);
	      if (vocal == 'a' || vocal == 'e' || vocal == 'i' || vocal == 'o' || vocal == 'u') 
	      {
	    	  cadenaConMayus += Character.toUpperCase(vocal);
	      } 
	      else 
	      {
	    	  cadenaConMayus += vocal;
	      }
	    }
	    System.out.println(cadenaConMayus);
	}
	
	//FizzBuzz
	/* Deberan imprimir los numeros del 1 al 100, sin embargo para los multiplos de 3
	deberan imprimir "Fizz" en lugar del numero, para los multiplos de 5 deberan imprimir
	"Buzz". Por ultimo, para los multiplos de 3 y 5 impriman "FizzBuzz".*/
	public void fizzBuzz()
	{
		for(i=1; i<101; i++)
		{
			if((i%3 == 0) && (i%5 !=0))
			{
				System.out.println("Fizz");
				continue;
			}
			if((i%5 == 0) && (i%3 !=0))
			{
				System.out.println("Buzz");
				continue;
			}
			if((i%3 == 0) && (i%5 == 0))
			{
				System.out.println("FizzBuzz");
				continue;
			}
			System.out.println(i);
		}
		return;
	}
	
	//Palindromo
	//Dada una cadena, escribe un programa para comprobar si es un palindromo
	public void palindromo()
	{
		System.out.println("Ingrese una cadena para verificar si es palindromo o no");
		palabra = scan.nextLine();
			izquierda = 0;
			derecha = palabra.length() - 1;
			resultado = 0;
			while(derecha > izquierda)
			{
				if (palabra.charAt(derecha) != palabra.charAt(izquierda)) 
				{
			        resultado = 1;
			    }
		      derecha--;
		      izquierda++;
			}
			if(resultado == 1)
			{
				System.out.println("La cadena NO es un palindromo");
			}
			else if (resultado == 0)
			{
				System.out.println("La cadena SI es un palindromo");
			}
		return;
	}
}