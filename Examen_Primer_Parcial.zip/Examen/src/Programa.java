
public class Programa {

	public static void main(String[] args) {

		Examen uno = new Examen();
		
		uno.primeraMayuscula();
		System.out.println();
		
		uno.invertirCadena();
		System.out.println();
		
		uno.vocalesMayuscula();
		System.out.println();
		
		uno.fizzBuzz();
		System.out.println();
		
		uno.palindromo();
	}

}
